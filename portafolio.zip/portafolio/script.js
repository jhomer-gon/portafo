function toggleMenu() {
    const menu = document.getElementById('menu');
    menu.classList.toggle('active');
}

document.getElementById('contact-form').addEventListener('submit', function(e) {
    e.preventDefault();
    alert("Mensaje enviado!");
});
